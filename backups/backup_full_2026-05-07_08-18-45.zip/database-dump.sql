-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: UniPartDB
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `UniPartDB`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `UniPartDB` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `UniPartDB`;

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applications` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `student_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_id` bigint NOT NULL,
  `status` enum('PENDING','ACCEPTED','REJECTED','COMPLETED') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING',
  `applied_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `student_id` (`student_id`,`job_id`),
  KEY `job_id` (`job_id`),
  CONSTRAINT `applications_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`) ON DELETE CASCADE,
  CONSTRAINT `applications_ibfk_2` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applications`
--

LOCK TABLES `applications` WRITE;
/*!40000 ALTER TABLE `applications` DISABLE KEYS */;
INSERT INTO `applications` VALUES (1,'58084ac6-666e-4bd8-801a-2c03cc728e36',3,'PENDING','2026-04-30 18:08:13',NULL),(2,'58084ac6-666e-4bd8-801a-2c03cc728e36',21,'PENDING','2026-05-01 00:48:28',NULL),(6,'58084ac6-666e-4bd8-801a-2c03cc728e36',11,'PENDING','2026-05-01 05:28:17',NULL),(7,'58084ac6-666e-4bd8-801a-2c03cc728e36',13,'PENDING','2026-05-01 05:38:15',NULL),(8,'58084ac6-666e-4bd8-801a-2c03cc728e36',14,'PENDING','2026-05-01 05:49:12',NULL),(9,'58084ac6-666e-4bd8-801a-2c03cc728e36',15,'PENDING','2026-05-01 06:30:30',NULL),(10,'58084ac6-666e-4bd8-801a-2c03cc728e36',24,'PENDING','2026-05-01 06:48:45',NULL),(11,'58084ac6-666e-4bd8-801a-2c03cc728e36',25,'PENDING','2026-05-01 06:54:29',NULL),(12,'58084ac6-666e-4bd8-801a-2c03cc728e36',23,'PENDING','2026-05-01 06:58:18',NULL),(13,'58084ac6-666e-4bd8-801a-2c03cc728e36',22,'PENDING','2026-05-01 07:01:21',NULL),(14,'58084ac6-666e-4bd8-801a-2c03cc728e36',20,'PENDING','2026-05-01 07:01:44',NULL),(15,'58084ac6-666e-4bd8-801a-2c03cc728e36',17,'PENDING','2026-05-01 17:24:35',NULL);
/*!40000 ALTER TABLE `applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_history`
--

DROP TABLE IF EXISTS `backup_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `date` datetime(6) NOT NULL,
  `duration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_history`
--

LOCK TABLES `backup_history` WRITE;
/*!40000 ALTER TABLE `backup_history` DISABLE KEYS */;
INSERT INTO `backup_history` VALUES (1,'2026-05-07 00:06:56.788109','0 giây','backup_full_2026-05-07_07-06-56.zip','failed','full'),(2,'2026-05-07 00:07:09.687572','0 giây','backup_full_2026-05-07_07-07-09.zip','failed','full'),(3,'2026-05-07 00:10:31.665344',NULL,'backup_full_2026-05-07_07-10-31.zip','running','full'),(4,'2026-05-07 01:18:45.545824',NULL,'backup_full_2026-05-07_08-18-45.zip','running','full');
/*!40000 ALTER TABLE `backup_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK41g4n0emuvcm3qyf1f6cn43c0` (`category_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_messages`
--

DROP TABLE IF EXISTS `chat_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_messages` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime(6) DEFAULT NULL,
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6f0y4l43ihmgfswkgy9yrtjkh` (`user_id`),
  CONSTRAINT `FK6f0y4l43ihmgfswkgy9yrtjkh` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_messages`
--

LOCK TABLES `chat_messages` WRITE;
/*!40000 ALTER TABLE `chat_messages` DISABLE KEYS */;
INSERT INTO `chat_messages` VALUES ('000a3c90-9dfa-4b89-a86a-a6802e3f46ab','Chào Minh Hiếu! Mình rất tiếc khi bạn bị đau tay. UniPart có một số công việc nhẹ nhàng, ít cần dùng sức tay mà bạn có thể tham khảo nhé. Các công việc này thường tập trung vào giao tiếp, tư duy hoặc thao tác nhẹ nhàng trên máy tính:\n\n*   **Nhân viên nhập liệu (ID: 14)**: Công việc chủ yếu là gõ máy tính, phù hợp nếu bạn có thể gõ nhẹ nhàng.\n*   **Nhân viên telesales (ID: 16)**: Công việc này chủ yếu là gọi điện và tư vấn khách hàng, ít dùng tay.\n*   **Lễ tân phòng gym (ID: 17)**: Đón tiếp khách và hỗ trợ đăng ký, thường làm việc tại quầy và dùng máy tính.\n*   **Gia sư Toán cấp 2 (ID: 13)**: Chủ yếu là giảng bài và hướng dẫn, không đòi hỏi sức lực nhiều.\n*   **Thu ngân (Cashier) (ID: 7)**: Thanh toán hóa đơn, chỉ cần thao tác nhẹ nhàng trên máy tính tiền.\n\nBạn có muốn mình lọc các công việc này theo khu vực gần bạn hoặc theo ca làm cụ thể không?','2026-05-01 14:48:44.007835','STUDENT','58084ac6-666e-4bd8-801a-2c03cc728e36'),('0c3db51c-d37e-4880-98fa-964bd193e2fe','các giá gói như nào','2026-05-02 00:18:42.180659','USER','89d76d9c-ce71-4de1-ab86-fb3f78ac964c'),('0ca1381b-dad5-4b33-9eee-4de991dcd022','Chào Minh Hiếu! Mình là UniBot, trợ lý AI thân thiện từ UniPart. Rất vui được hỗ trợ bạn tìm kiếm các công việc làm thêm phù hợp với lịch học và sở thích của sinh viên FPT. Bạn đang tìm kiếm công việc như thế nào hay có câu hỏi gì về UniPart không?','2026-05-01 14:45:01.250597','STUDENT','58084ac6-666e-4bd8-801a-2c03cc728e36'),('193723ee-ac3c-4746-9cfb-1fb5fedd8aba','tôi bị đau tay kiếm việc cho tôi','2026-05-01 14:50:25.665362','USER','58084ac6-666e-4bd8-801a-2c03cc728e36'),('1c544fd2-0cd7-48d0-8ad7-61c7909f32ca','1+1 bằng mấy','2026-05-01 14:45:26.395070','USER','58084ac6-666e-4bd8-801a-2c03cc728e36'),('1edffd3c-7538-4ad7-b1ec-5b04c3ec58b6','Chào anh/chị, dưới đây là bảng giá chi tiết các gói đăng tin tuyển dụng trên UniPart:\n\n**Các Gói Theo Tháng (Tiết kiệm và hiệu quả cho nhu cầu thường xuyên):**\n- **Gói Basic (ID: 1):** 2.700.000 VNĐ/tháng. Bao gồm 60 tin thường (tối đa 2 tin/ngày) và 5 tin tuyển gấp.\n- **Gói Advance (ID: 2):** 6.000.000 VNĐ/tháng. Bao gồm 150 tin thường (tối đa 5 tin/ngày) và 10 tin tuyển gấp.\n- **Gói Premium (ID: 3):** 10.500.000 VNĐ/tháng. Bao gồm 300 tin thường (tối đa 10 tin/ngày) và 20 tin tuyển gấp.\n\n**Các Gói Đăng Tin Lẻ (Linh hoạt cho nhu cầu đột xuất):**\n- **Tin Thường:**\n  - **1 Tin (ID: 4):** 50.000 VNĐ\n  - **3 Tin (ID: 5):** 135.000 VNĐ\n  - **5 Tin (ID: 6):** 200.000 VNĐ\n- **Tin Tuyển Gấp:**\n  - **1 Tin (ID: 7):** 70.000 VNĐ\n  - **3 Tin (ID: 8):** 189.000 VNĐ\n  - **5 Tin (ID: 9):** 224.000 VNĐ\n\nAnh/chị quan tâm đến gói nào hoặc cần tư vấn thêm về gói phù hợp với nhu cầu của mình không ạ?','2026-05-04 12:59:01.641919','EMPLOYER','89d76d9c-ce71-4de1-ab86-fb3f78ac964c'),('2b06ab53-7109-48c4-b196-bb7275445c84','Chào Minh Hiếu! UniPart đã tìm thấy một số công việc có mức lương hấp dẫn mà bạn có thể quan tâm đây:','2026-05-02 00:08:25.235194','STUDENT','58084ac6-666e-4bd8-801a-2c03cc728e36'),('3c58f5ce-1331-40f1-bb5f-c4dacd8c9605','chào bạn','2026-05-01 14:44:56.439709','USER','58084ac6-666e-4bd8-801a-2c03cc728e36'),('40e8bc11-80b2-442b-ae9c-66a58b8d4439','Chào anh/chị. Với vai trò là UniBot, em chỉ có thể hỗ trợ các thông tin liên quan đến nền tảng UniPart, việc làm, tuyển dụng hoặc các kỹ năng mềm. Anh/chị có câu hỏi nào về cách UniPart có thể giúp công ty [uawdwd] tìm kiếm nhân sự hiệu quả không ạ?','2026-05-04 15:25:48.785126','EMPLOYER','89d76d9c-ce71-4de1-ab86-fb3f78ac964c'),('46056918-087c-41cc-a513-adcd81bc22e1','Tìm việc lương cao','2026-05-02 00:08:20.031145','USER','58084ac6-666e-4bd8-801a-2c03cc728e36'),('51489014-6a93-47fa-8220-9cee75644343','Chào Minh Hiếu! UniPart có nhiều công việc làm thêm cuối tuần rất phù hợp với sinh viên như bạn. Dưới đây là một vài gợi ý bạn có thể tham khảo:','2026-05-02 00:07:20.371208','STUDENT','58084ac6-666e-4bd8-801a-2c03cc728e36'),('551c3c08-3366-4cf1-8a21-3c6ba5f0b438','1+1 bằng mấy','2026-05-01 14:47:12.674563','USER','58084ac6-666e-4bd8-801a-2c03cc728e36'),('5c8bea8b-aaa4-475d-bf6c-210e42f0e9e3','Chào Hiếu! Mình rất tiếc khi nghe bạn bị đau tay. Để giúp bạn tìm được công việc phù hợp mà không ảnh hưởng đến sức khỏe, mình đã lọc ra một số công việc ít đòi hỏi vận động tay chân hoặc có tính chất linh hoạt hơn trên UniPart nhé: Bạn có muốn mình tìm thêm công việc nào khác hoặc lọc theo tiêu chí nào không?','2026-05-01 14:50:50.182996','STUDENT','58084ac6-666e-4bd8-801a-2c03cc728e36'),('6953d8f6-304d-467e-b858-ff3aa69f01e4','Tìm việc lương cao','2026-05-04 12:52:01.624277','USER','89d76d9c-ce71-4de1-ab86-fb3f78ac964c'),('6fa4dd7b-396e-4f58-8d28-d4f8805b24ec','Chào anh/chị từ ABC Company! Anh/chị đang quan tâm đến việc tìm hiểu về các mức lương trên thị trường hoặc cách thu hút các ứng viên chất lượng cao bằng mức lương hấp dẫn phải không ạ? Trên UniPart, việc đưa ra mức lương cạnh tranh là một cách tuyệt vời để thu hút sinh viên tài năng. Anh/chị có muốn mình hướng dẫn cách tối ưu tin tuyển dụng để làm nổi bật mức lương và thu hút nhiều ứng viên tiềm năng không?','2026-05-04 12:52:16.364976','EMPLOYER','89d76d9c-ce71-4de1-ab86-fb3f78ac964c'),('76adf246-06ef-40fb-b65f-c049dfac3b33','bạn duy khánh là ai','2026-05-04 15:25:41.048320','USER','89d76d9c-ce71-4de1-ab86-fb3f78ac964c'),('7fd662f9-d959-4da6-8c3a-1da5c28e7ac1','Chào Minh Hiếu, mình rất tiếc khi nghe bạn đang bị đau tay. UniBot sẽ giúp bạn tìm những công việc phù hợp, ít phải dùng tay nhé! Dựa trên tình trạng của bạn, mình gợi ý một số công việc sau đây:','2026-05-01 14:50:56.383061','STUDENT','58084ac6-666e-4bd8-801a-2c03cc728e36'),('856bb4af-5cc3-4949-9114-53d9c5c5792e','Cách thanh toán?','2026-05-04 12:59:34.428493','USER','89d76d9c-ce71-4de1-ab86-fb3f78ac964c'),('87f1ff35-c909-4e3a-b386-445526bacd38','Bảng giá các gói?','2026-05-04 11:59:36.781890','USER','89d76d9c-ce71-4de1-ab86-fb3f78ac964c'),('88875915-15c2-4f76-8a30-543d9536426f','Chào anh/chị, UniBot sẵn lòng cung cấp thông tin chi tiết về các gói tin tuyển dụng trên UniPart để anh/chị có thể lựa chọn phù hợp nhất cho ABC Company:\n\n**Các Gói Tháng (Đăng tin linh hoạt):**\n*   **Gói Basic (ID: 1):** 2.700.000 VNĐ/tháng. Bao gồm 60 tin thường (tối đa 2 tin/ngày) và 5 tin tuyển gấp.\n*   **Gói Advance (ID: 2):** 6.000.000 VNĐ/tháng. Bao gồm 150 tin thường (tối đa 5 tin/ngày) và 10 tin tuyển gấp.\n*   **Gói Premium (ID: 3):** 10.500.000 VNĐ/tháng. Bao gồm 300 tin thường (tối đa 10 tin/ngày) và 20 tin tuyển gấp.\n\n**Các Gói Đăng Tin Lẻ (Pay-Per-Tin):**\n*   **1 Tin Bình Thường (ID: 4):** 50.000 VNĐ\n*   **3 Tin Bình Thường (ID: 5):** 135.000 VNĐ\n*   **5 Tin Bình Thường (ID: 6):** 200.000 VNĐ\n*   **1 Tin Tuyển Gấp (ID: 7):** 70.000 VNĐ\n*   **3 Tin Tuyển Gấp (ID: 8):** 189.000 VNĐ\n*   **5 Tin Tuyển Gấp (ID: 9):** 224.000 VNĐ\n\nAnh/chị có thể tham khảo các gói trên để chọn lựa phương án tối ưu cho nhu cầu tuyển dụng của mình. Anh/chị có cần mình tư vấn thêm về gói nào không ạ?','2026-05-04 12:56:56.015765','EMPLOYER','89d76d9c-ce71-4de1-ab86-fb3f78ac964c'),('8b3a04ad-794a-4b29-97e5-f654a29ce685','Bảng giá các gói?','2026-05-04 12:56:50.400809','USER','89d76d9c-ce71-4de1-ab86-fb3f78ac964c'),('92355502-5480-4622-926d-14bdc4157cf7','Chào anh/chị, UniPart có nhiều gói tin linh hoạt để phù hợp với nhu cầu tuyển dụng của công ty ABC Company. Dưới đây là thông tin chi tiết về các gói:\n\n**1. Các Gói Tin Theo Tháng (Phù hợp cho nhu cầu tuyển dụng thường xuyên):**\n*   **Gói Basic (ID: 1):** 2.700.000 VNĐ/tháng. Bao gồm 60 tin thường (tối đa 2 tin/ngày) và 5 tin tuyển gấp.\n*   **Gói Advance (ID: 2):** 6.000.000 VNĐ/tháng. Bao gồm 150 tin thường (tối đa 5 tin/ngày) và 10 tin tuyển gấp.\n*   **Gói Premium (ID: 3):** 10.500.000 VNĐ/tháng. Bao gồm 300 tin thường (tối đa 10 tin/ngày) và 20 tin tuyển gấp.\n\n**2. Các Gói Tin Lẻ (Phù hợp cho nhu cầu tuyển dụng không thường xuyên):**\n*   **Tin Bình Thường:**\n    *   **1 Tin Bình Thường (ID: 4):** 50.000 VNĐ\n    *   **3 Tin Bình Thường (ID: 5):** 135.000 VNĐ\n    *   **5 Tin Bình Thường (ID: 6):** 200.000 VNĐ\n*   **Tin Tuyển Gấp:**\n    *   **1 Tin Tuyển Gấp (ID: 7):** 70.000 VNĐ\n    *   **3 Tin Tuyển Gấp (ID: 8):** 189.000 VNĐ\n    *   **5 Tin Tuyển Gấp (ID: 9):** 224.000 VNĐ\n\nAnh/chị có thể lựa chọn gói phù hợp nhất với tần suất và số lượng tin tuyển dụng của mình. Anh/chị có muốn mình tư vấn thêm về gói nào không?','2026-05-02 00:18:49.519545','EMPLOYER','89d76d9c-ce71-4de1-ab86-fb3f78ac964c'),('984255cb-9fe3-4b16-aaf6-9d7d5db547b4','Chào Minh Hiếu! Mình là UniBot, trợ lý của UniPart. Mình rất tiếc nhưng mình chỉ có thể hỗ trợ bạn các thông tin liên quan đến việc tìm việc làm thêm, sử dụng nền tảng UniPart hoặc các vấn đề về kỹ năng mềm thôi. Bạn có câu hỏi nào về các công việc bán thời gian hay cách UniPart có thể giúp bạn không?','2026-05-01 14:47:39.504744','STUDENT','58084ac6-666e-4bd8-801a-2c03cc728e36'),('9b80b503-d248-484f-bd8f-57629e889315','Chào anh/chị, UniPart có nhiều gói tin tuyển dụng linh hoạt để phù hợp với nhu cầu của ABC Company. Dưới đây là bảng giá chi tiết các gói tin của chúng tôi:\n\n**Các Gói Hàng Tháng:**\n*   **Gói Basic (ID 1):** 2.700.000 VNĐ/tháng. Bao gồm 60 tin thường (tối đa 2 tin/ngày) và 5 tin tuyển gấp.\n*   **Gói Advance (ID 2):** 6.000.000 VNĐ/tháng. Bao gồm 150 tin thường (tối đa 5 tin/ngày) và 10 tin tuyển gấp.\n*   **Gói Premium (ID 3):** 10.500.000 VNĐ/tháng. Bao gồm 300 tin thường (tối đa 10 tin/ngày) và 20 tin tuyển gấp.\n\n**Các Gói Mua Lẻ Tin (Pay-per-tin):**\n*   **1 Tin Bình Thường (ID 4):** 50.000 VNĐ/tin.\n*   **3 Tin Bình Thường (ID 5):** 135.000 VNĐ/3 tin.\n*   **5 Tin Bình Thường (ID 6):** 200.000 VNĐ/5 tin.\n*   **1 Tin Tuyển Gấp (ID 7):** 70.000 VNĐ/tin.\n*   **3 Tin Tuyển Gấp (ID 8):** 189.000 VNĐ/3 tin.\n*   **5 Tin Tuyển Gấp (ID 9):** 224.000 VNĐ/5 tin.\n\nAnh/chị quan tâm đến gói nào hoặc cần tư vấn thêm về cách chọn gói phù hợp với nhu cầu tuyển dụng của mình không ạ?','2026-05-04 11:59:46.645795','EMPLOYER','89d76d9c-ce71-4de1-ab86-fb3f78ac964c'),('a346aa54-0483-4c39-ab81-698e4fc9bd34','Chào Nguyễn Minh Hiếu! Mình là UniBot, trợ lý của UniPart. Mình chuyên hỗ trợ các bạn sinh viên tìm việc làm thêm, hướng dẫn sử dụng nền tảng và chia sẻ kinh nghiệm làm việc. Về câu hỏi 1+1, mình xin phép không trả lời vì nó nằm ngoài chuyên môn của mình. Bạn có muốn mình giúp tìm một công việc làm thêm phù hợp với lịch học của bạn không?','2026-05-01 14:45:33.539148','STUDENT','58084ac6-666e-4bd8-801a-2c03cc728e36'),('bcc7ab2d-9e36-4c31-b941-8976822b5a07','Chào anh/chị, để thanh toán trên UniPart, anh/chị có thể lựa chọn các gói tin tuyển dụng phù hợp với nhu cầu của mình. Sau khi chọn gói, hệ thống sẽ chuyển sang bước thanh toán an toàn, nơi anh/chị có thể sử dụng các phương thức như chuyển khoản ngân hàng, ví điện tử hoặc thẻ tín dụng/ghi nợ. Anh/chị có muốn mình hướng dẫn cụ thể cách chọn gói và tiến hành thanh toán không ạ?','2026-05-04 12:59:39.051082','EMPLOYER','89d76d9c-ce71-4de1-ab86-fb3f78ac964c'),('ccbfa255-3887-4243-a225-ce9db8e9a7a0','Chào Nguyễn Minh Hiếu! Mình là UniBot, trợ lý của nền tảng UniPart. Mình chỉ có thể hỗ trợ bạn các vấn đề liên quan đến tìm việc làm thêm, tuyển dụng, và cách sử dụng các tính năng của UniPart thôi. Bạn có câu hỏi nào về việc làm thêm hay cần mình hướng dẫn sử dụng ứng dụng không?','2026-05-01 14:47:15.779799','STUDENT','58084ac6-666e-4bd8-801a-2c03cc728e36'),('d975cedc-2ae6-4005-8994-3a47dd2e09ea','bác hồ ra đi tìm đường cứu nước năm bao nhiêu','2026-05-01 14:46:26.393527','USER','58084ac6-666e-4bd8-801a-2c03cc728e36'),('e034d771-e2db-4b6d-aca6-935bc8d81e09','tôi bị đau tay bạn ó công việc nào nhẹ nhàng không','2026-05-01 14:48:18.771060','USER','58084ac6-666e-4bd8-801a-2c03cc728e36'),('e3fba60a-17ae-4feb-8841-daca31c96c44','tôi bị đau tay kiếm việc cho tôi','2026-05-01 14:50:48.164335','USER','58084ac6-666e-4bd8-801a-2c03cc728e36'),('ee1ee777-ac92-4ce4-9064-f59c002d0377','Việc làm cuối tuần','2026-05-02 00:07:12.685053','USER','58084ac6-666e-4bd8-801a-2c03cc728e36'),('fec6faff-232a-4007-a33c-3fa677c31e77','Bảng giá các gói?','2026-05-04 12:58:50.642332','USER','89d76d9c-ce71-4de1-ab86-fb3f78ac964c');
/*!40000 ALTER TABLE `chat_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `post_id` bigint NOT NULL,
  `user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `parent_comment_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`),
  KEY `FK7h839m3lkvhbyv3bcdv7sm4fj` (`parent_comment_id`),
  KEY `FK8omq0tc18jd43bu5tjh6jvraq` (`user_id`),
  CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `student` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK7h839m3lkvhbyv3bcdv7sm4fj` FOREIGN KEY (`parent_comment_id`) REFERENCES `comments` (`id`),
  CONSTRAINT `FK8omq0tc18jd43bu5tjh6jvraq` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employer`
--

DROP TABLE IF EXISTS `employer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employer` (
  `id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `rating` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_employer_user` FOREIGN KEY (`id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employer`
--

LOCK TABLES `employer` WRITE;
/*!40000 ALTER TABLE `employer` DISABLE KEYS */;
INSERT INTO `employer` VALUES ('89d76d9c-ce71-4de1-ab86-fb3f78ac964c','uawdwd','Hanoi',NULL,NULL,'',NULL),('EMP001','Highlands Coffee Quận 1','123 Lê Lợi, Phường Bến Thành, Quận 1, TP.HCM',10.7712,106.6983,'Chuỗi cửa hàng cà phê hàng đầu Việt Nam, môi trường năng động.',4.5);
/*!40000 ALTER TABLE `employer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employer_package_purchase`
--

DROP TABLE IF EXISTS `employer_package_purchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employer_package_purchase` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `employer_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `package_id` bigint NOT NULL,
  `purchased_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `price_paid` decimal(12,2) NOT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `tins_purchased` int DEFAULT NULL,
  `payment_status` tinyint DEFAULT NULL,
  `transaction_ref` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_purchase_employer` (`employer_id`),
  KEY `fk_purchase_package` (`package_id`),
  CONSTRAINT `fk_purchase_employer` FOREIGN KEY (`employer_id`) REFERENCES `employer` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_purchase_package` FOREIGN KEY (`package_id`) REFERENCES `package` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `employer_package_purchase_chk_1` CHECK ((`payment_status` between 0 and 2))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employer_package_purchase`
--

LOCK TABLES `employer_package_purchase` WRITE;
/*!40000 ALTER TABLE `employer_package_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `employer_package_purchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invalidated_token`
--

DROP TABLE IF EXISTS `invalidated_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invalidated_token` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiry_date` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invalidated_token`
--

LOCK TABLES `invalidated_token` WRITE;
/*!40000 ALTER TABLE `invalidated_token` DISABLE KEYS */;
INSERT INTO `invalidated_token` VALUES ('05e36b2a-4fa2-4261-a7d4-f71926c8b76f','2026-09-29 00:21:38.000000'),('13209c69-1ce8-4133-9eb4-00075fd8fc9f','2026-10-02 07:16:30.000000'),('18d0b763-1ec1-431a-9b29-db7250474c5a','2026-09-29 00:11:12.000000'),('1a4ceb95-12b5-497b-afc2-b178452d6cb0','2026-10-02 07:21:16.000000'),('223a5864-7006-4930-91f9-5ed3a966681c','2026-10-03 00:59:02.000000'),('2375e136-c4f7-4dc2-83cc-22569d6d501f','2026-10-02 07:16:06.000000'),('2d752ff9-af67-429a-a014-47857b58a78e','2026-09-28 00:02:13.000000'),('32c1ef78-bc5a-4a32-a43d-ddd0a19fb49d','2026-10-03 00:02:11.000000'),('3d3932f2-0a14-4987-b9f9-6d191df69fab','2026-10-03 00:01:59.000000'),('43349b0e-e8d3-415c-aa52-35cedc1fc670','2026-10-01 13:00:00.000000'),('78a6e57e-9c5f-41c2-954b-3282d7dc38f8','2026-10-03 00:10:10.000000'),('a09f87b2-a891-4496-8a1b-c8df82c6c4d7','2026-10-02 06:41:01.000000'),('a0cfa0cd-a2b9-47e6-a417-238eabb16672','2026-09-27 08:17:21.000000'),('ab5dc6e6-99c2-4084-937f-01b73ad568b6','2026-10-02 07:16:35.000000'),('ab96e310-7871-426e-b7b2-673abaddded3','2026-09-29 00:21:26.000000'),('b524b10f-2c48-4521-8953-6e9ed9eea19e','2026-10-01 13:10:37.000000'),('c4775c7c-0681-4aab-9053-be73249daef0','2026-10-03 00:59:50.000000'),('c4bfd2fe-5ce1-485e-af7d-304bae73d2f3','2026-10-02 06:43:43.000000'),('c6c65d37-eb9b-4add-86c5-6e59b539463b','2026-10-03 00:26:21.000000'),('caa57c62-6728-46b4-9392-30377e8f44d4','2026-09-27 08:03:49.000000'),('d3bfb679-8374-4a00-bb09-b0496f81049b','2026-10-01 13:02:04.000000'),('d91628c3-f3a7-461d-abec-36d82a6e5706','2026-09-29 00:16:09.000000'),('e10278e8-ffce-4a96-b8a9-a944401b79a1','2026-10-02 07:14:02.000000'),('e3707236-5ea3-4f7a-825b-02d079187fbe','2026-10-02 07:03:42.000000'),('e589b4c6-a7a5-46e0-bf4b-80f878d672fc','2026-10-02 07:16:15.000000'),('e61b05f0-3be1-4c7b-a40e-2d79e81ead47','2026-10-02 06:43:33.000000'),('ec2ea14f-763c-49e0-8f55-d29699502915','2026-09-26 09:54:42.000000'),('ecd962f4-6235-4488-8d54-506be4ec619d','2026-10-02 06:33:12.000000');
/*!40000 ALTER TABLE `invalidated_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_time_slots`
--

DROP TABLE IF EXISTS `job_time_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_time_slots` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` bigint NOT NULL,
  `work_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  PRIMARY KEY (`id`),
  KEY `job_id` (`job_id`),
  CONSTRAINT `job_time_slots_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_time_slots`
--

LOCK TABLES `job_time_slots` WRITE;
/*!40000 ALTER TABLE `job_time_slots` DISABLE KEYS */;
INSERT INTO `job_time_slots` VALUES (1,1,'2026-05-01','07:00:00','12:00:00'),(2,1,'2026-05-02','07:00:00','12:00:00'),(3,3,'2026-05-01','08:00:00','16:00:00');
/*!40000 ALTER TABLE `job_time_slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `employer_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `working_shift` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vacancies` int NOT NULL,
  `urgent` tinyint(1) DEFAULT '0',
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_latitude` decimal(10,8) DEFAULT NULL,
  `location_longitude` decimal(11,8) DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `isHide` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `expired_at` datetime DEFAULT NULL,
  `is_hide` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employer_id` (`employer_id`),
  KEY `idx_jobs_location` (`location_latitude`,`location_longitude`),
  CONSTRAINT `jobs_ibfk_1` FOREIGN KEY (`employer_id`) REFERENCES `employer` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (1,'EMP001','Phục vụ Coffee Sáng',NULL,'Phục vụ khách hàng, dọn dẹp bàn ghế ca sáng.','Ca Sáng',5,0,'123 Lê Lợi, Quận 1',NULL,NULL,25000.00,0,'2026-04-30 08:01:41','2026-05-26 23:59:59',NULL),(2,'EMP001','Phục vụ Coffee Chiều',NULL,'Phục vụ khách hàng ca chiều, pha chế cơ bản.','Ca Chiều',3,0,'123 Lê Lợi, Quận 1',NULL,NULL,25000.00,0,'2026-04-30 08:01:41','2026-05-26 23:59:59',NULL),(3,'EMP001','Pha chế (Barista) - Tuyển Gấp',NULL,'Pha chế các loại đồ uống theo công thức có sẵn.','Ca Linh Hoạt',2,1,'123 Lê Lợi, Quận 1',NULL,NULL,35000.00,0,'2026-04-30 08:01:41','2026-05-10 23:59:59',NULL),(4,'EMP001','Nhân viên Kho',NULL,'Kiểm kê hàng hóa, nhập kho nguyên liệu.','Ca Tối',1,0,'123 Lê Lợi, Quận 1',NULL,NULL,28000.00,0,'2026-04-30 08:01:41','2026-05-30 23:59:59',NULL),(5,'EMP001','Bảo vệ giữ xe',NULL,'Dắt xe và trông coi xe cho khách.','Full-time',2,0,'123 Lê Lợi, Quận 1',NULL,NULL,22000.00,0,'2026-04-30 08:01:41','2026-06-15 23:59:59',NULL),(6,'EMP001','Tạp vụ cửa hàng',NULL,'Vệ sinh khu vực sảnh và nhà vệ sinh.','Ca Sáng',1,0,'123 Lê Lợi, Quận 1',NULL,NULL,20000.00,0,'2026-04-30 08:01:41','2026-05-20 23:59:59',NULL),(7,'EMP001','Thu ngân (Cashier)',NULL,'Thanh toán hóa đơn cho khách tại quầy.','Ca Chiều',2,1,'123 Lê Lợi, Quận 1',NULL,NULL,30000.00,0,'2026-04-30 08:01:41','2026-05-15 23:59:59',NULL),(8,'EMP001','Giao hàng (Shipper)',NULL,'Giao đồ uống cho khách trong bán kính 3km.','Tự do',5,0,'123 Lê Lợi, Quận 1',NULL,NULL,40000.00,0,'2026-04-30 08:01:41','2026-07-01 23:59:59',NULL),(9,'EMP001','Quản lý ca (Shift Leader)',NULL,'Điều phối nhân viên trong ca làm việc.','Xoay ca',1,0,'123 Lê Lợi, Quận 1',NULL,NULL,50000.00,0,'2026-04-30 08:01:41','2026-08-01 23:59:59',NULL),(10,'EMP001','Nhân viên Marketing Part-time',NULL,'Hỗ trợ chụp ảnh, viết bài Fanpage.','Làm tại nhà',1,0,'Văn phòng Quận 1',NULL,NULL,45000.00,0,'2026-04-30 08:01:41','2026-06-01 23:59:59',NULL),(11,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Nhân viên phục vụ trà sữa',NULL,'Phục vụ khách, dọn dẹp khu vực quán.','Ca Sáng',4,0,'45 Chùa Láng, Đống Đa, Hà Nội',NULL,NULL,26000.00,0,'2026-05-01 07:35:25','2026-05-30 23:59:59',NULL),(12,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Nhân viên bán hàng thời trang',NULL,'Tư vấn khách, sắp xếp quần áo.','Ca Chiều',3,1,'12 Phố Huế, Hai Bà Trưng, Hà Nội',NULL,NULL,30000.00,0,'2026-05-01 07:35:25','2026-05-20 23:59:59',NULL),(13,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Gia sư Toán cấp 2',NULL,'Dạy kèm học sinh tại nhà.','Tối',2,0,'Cầu Giấy, Hà Nội',NULL,NULL,100000.00,0,'2026-05-01 07:35:25','2026-06-15 23:59:59',NULL),(14,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Nhân viên nhập liệu',NULL,'Nhập dữ liệu vào hệ thống.','Làm tại nhà',2,0,'Remote',NULL,NULL,40000.00,0,'2026-05-01 07:35:25','2026-06-01 23:59:59',NULL),(15,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Shipper giao hàng nội thành',NULL,'Giao hàng trong khu vực nội thành.','Tự do',5,0,'Thanh Xuân, Hà Nội',NULL,NULL,45000.00,0,'2026-05-01 07:35:25','2026-07-01 23:59:59',NULL),(16,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Nhân viên telesales',NULL,'Gọi điện tư vấn khách hàng.','Full-time',3,1,'Keangnam, Nam Từ Liêm, Hà Nội',NULL,NULL,35000.00,0,'2026-05-01 07:35:25','2026-05-25 23:59:59',NULL),(17,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Lễ tân phòng gym',NULL,'Đón tiếp khách và hỗ trợ đăng ký.','Ca Xoay',2,0,'Times City, Hai Bà Trưng, Hà Nội',NULL,NULL,28000.00,0,'2026-05-01 07:35:25','2026-06-10 23:59:59',NULL),(18,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Nhân viên thiết kế Canva',NULL,'Thiết kế banner, post Facebook.','Part-time',1,0,'Remote',NULL,NULL,50000.00,0,'2026-05-01 07:35:25','2026-06-20 23:59:59',NULL),(19,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Phụ bếp nhà hàng',NULL,'Sơ chế nguyên liệu, hỗ trợ bếp.','Ca Tối',2,0,'Phố Cổ, Hoàn Kiếm, Hà Nội',NULL,NULL,30000.00,0,'2026-05-01 07:35:25','2026-05-28 23:59:59',NULL),(20,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Nhân viên IT Support',NULL,'Hỗ trợ kỹ thuật máy tính văn phòng.','Giờ hành chính',1,0,'Duy Tân, Cầu Giấy, Hà Nội',NULL,NULL,60000.00,0,'2026-05-01 07:35:25','2026-07-10 23:59:59',NULL),(21,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Nhân viên quay video TikTok',NULL,'Quay và dựng video ngắn.','Linh hoạt',1,1,'Long Biên, Hà Nội',NULL,NULL,70000.00,0,'2026-05-01 07:35:25','2026-06-05 23:59:59',NULL),(22,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Bảo vệ tòa nhà',NULL,'Trông coi an ninh.','Full-time',2,0,'Mỹ Đình, Nam Từ Liêm, Hà Nội',NULL,NULL,25000.00,0,'2026-05-01 07:35:25','2026-06-30 23:59:59',NULL),(23,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Nhân viên chăm sóc khách hàng',NULL,'Hỗ trợ khách qua chat.','Ca Chiều',3,0,'Đống Đa, Hà Nội',NULL,NULL,32000.00,0,'2026-05-01 07:35:25','2026-05-22 23:59:59',NULL),(24,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Freelancer viết content',NULL,'Viết bài SEO website.','Remote',2,0,'Remote',NULL,NULL,80000.00,0,'2026-05-01 07:35:25','2026-07-15 23:59:59',NULL),(25,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Nhân viên rửa xe',NULL,'Rửa xe máy, ô tô.','Ca Sáng',2,0,'Hoàng Mai, Hà Nội',NULL,NULL,27000.00,0,'2026-05-01 07:35:25','2026-05-18 23:59:59',NULL);
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_read` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_notification_user` (`user_id`),
  CONSTRAINT `fk_notification_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES (1,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Ứng tuyển công việc','Sinh viên Nguyễn Minh Hiếu muốn làm công việc này',1,'2026-05-01 12:38:15'),(2,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Ứng tuyển công việc','Sinh viên Nguyễn Minh Hiếu muốn làm công việc này',1,'2026-05-01 12:49:13'),(3,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Ứng tuyển công việc','Sinh viên Nguyễn Minh Hiếu muốn làm công việc Shipper giao hàng nội thành',1,'2026-05-01 13:30:30'),(4,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Ứng tuyển công việc','Sinh viên Nguyễn Minh Hiếu muốn làm công việc Freelancer viết content',1,'2026-05-01 13:48:45'),(5,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Ứng tuyển công việc','Sinh viên Nguyễn Minh Hiếu muốn làm công việc Nhân viên rửa xe',1,'2026-05-01 13:54:29'),(6,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Ứng tuyển công việc','Sinh viên Nguyễn Minh Hiếu muốn làm công việc Nhân viên chăm sóc khách hàng',1,'2026-05-01 13:58:18'),(7,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Ứng tuyển công việc','Sinh viên Nguyễn Minh Hiếu muốn làm công việc Bảo vệ tòa nhà',1,'2026-05-01 14:01:21'),(8,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Ứng tuyển công việc','Sinh viên Nguyễn Minh Hiếu muốn làm công việc Nhân viên IT Support',1,'2026-05-01 14:01:44'),(9,'89d76d9c-ce71-4de1-ab86-fb3f78ac964c','Ứng tuyển công việc','Sinh viên Nguyễn Minh Hiếu muốn làm công việc Lễ tân phòng gym',1,'2026-05-02 00:24:35');
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otp`
--

DROP TABLE IF EXISTS `otp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `otp` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration_time` datetime(6) NOT NULL,
  `is_used` bit(1) NOT NULL,
  `otp_code` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otp`
--

LOCK TABLES `otp` WRITE;
/*!40000 ALTER TABLE `otp` DISABLE KEYS */;
INSERT INTO `otp` VALUES ('2aba20a3-1c86-40cb-891d-6e7c651a7847','2026-05-06 00:57:43.073159','nguyenminhhieucoder01@gmail.com','2026-05-06 01:02:43.073159',_binary '',470960),('7ecfc171-c588-4eb7-83b5-e69641c5a0cb','2026-05-05 08:28:47.407179','minhhieu@gmail.com','2026-05-05 08:33:47.407179',_binary '\0',564534),('b2458309-5619-47e3-9903-2d7f002fd052','2026-04-30 08:03:20.822095','nguyenhieutd2k4@gmail.com','2026-04-30 08:08:20.822095',_binary '',959202);
/*!40000 ALTER TABLE `otp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package`
--

DROP TABLE IF EXISTS `package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `package` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `package_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `duration_days` int DEFAULT NULL,
  `normal_tins_limit` int DEFAULT NULL,
  `max_normal_tins_per_day` int DEFAULT NULL,
  `urgent_tins_limit` int DEFAULT NULL,
  `tin_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tin_quantity` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package`
--

LOCK TABLES `package` WRITE;
/*!40000 ALTER TABLE `package` DISABLE KEYS */;
INSERT INTO `package` VALUES (1,'Gói Basic','MONTHLY',2700000.00,'60 tin thường/tháng (tối đa 2 tin/ngày), 5 tin tuyển gấp',30,60,2,5,NULL,NULL,'2026-04-30 08:01:41',NULL),(2,'Gói Advance','MONTHLY',6000000.00,'150 tin thường/tháng (tối đa 5 tin/ngày), 10 tin tuyển gấp',30,150,5,10,NULL,NULL,'2026-04-30 08:01:41',NULL),(3,'Gói Premium','MONTHLY',10500000.00,'300 tin thường/tháng (tối đa 10 tin/ngày), 20 tin tuyển gấp',30,300,10,20,NULL,NULL,'2026-04-30 08:01:41',NULL),(4,'1 Tin Bình Thường','PAY_PER_TIN',50000.00,'Tin bình thường 1 tin',NULL,NULL,NULL,NULL,'NORMAL',1,'2026-04-30 08:01:41',NULL),(5,'3 Tin Bình Thường','PAY_PER_TIN',135000.00,'Tin bình thường 3 tin',NULL,NULL,NULL,NULL,'NORMAL',3,'2026-04-30 08:01:41',NULL),(6,'5 Tin Bình Thường','PAY_PER_TIN',200000.00,'Tin bình thường 5 tin',NULL,NULL,NULL,NULL,'NORMAL',5,'2026-04-30 08:01:41',NULL),(7,'1 Tin Tuyển Gấp','PAY_PER_TIN',70000.00,'Tin tuyển gấp 1 tin',NULL,NULL,NULL,NULL,'URGENT',1,'2026-04-30 08:01:41',NULL),(8,'3 Tin Tuyển Gấp','PAY_PER_TIN',189000.00,'Tin tuyển gấp 3 tin',NULL,NULL,NULL,NULL,'URGENT',3,'2026-04-30 08:01:41',NULL),(9,'5 Tin Tuyển Gấp','PAY_PER_TIN',224000.00,'Tin tuyển gấp 5 tin',NULL,NULL,NULL,NULL,'URGENT',5,'2026-04-30 08:01:41',NULL);
/*!40000 ALTER TABLE `package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_likes`
--

DROP TABLE IF EXISTS `post_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_likes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `post_id` bigint NOT NULL,
  `user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK5l2rj28vw5oj6f7ox746grokg` (`post_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_likes`
--

LOCK TABLES `post_likes` WRITE;
/*!40000 ALTER TABLE `post_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `related_job_id` bigint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `category_id` bigint DEFAULT NULL,
  `comments_count` int DEFAULT NULL,
  `likes_count` int DEFAULT NULL,
  `shares_count` int DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `related_job_id` (`related_job_id`),
  KEY `FKijnwr3brs8vaosl80jg9rp7uc` (`category_id`),
  KEY `FK5lidm6cqbc7u4xhqpxm898qme` (`user_id`),
  CONSTRAINT `FK5lidm6cqbc7u4xhqpxm898qme` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `FKijnwr3brs8vaosl80jg9rp7uc` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `student` (`id`) ON DELETE CASCADE,
  CONSTRAINT `posts_ibfk_2` FOREIGN KEY (`related_job_id`) REFERENCES `jobs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report`
--

DROP TABLE IF EXISTS `report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `reporter_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `admin_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `resolved_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_report_user` (`reporter_id`),
  KEY `FKohgb4rfq2d25jqs4mdgy6ryho` (`resolved_by`),
  CONSTRAINT `fk_report_user` FOREIGN KEY (`reporter_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FKohgb4rfq2d25jqs4mdgy6ryho` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report`
--

LOCK TABLES `report` WRITE;
/*!40000 ALTER TABLE `report` DISABLE KEYS */;
/*!40000 ALTER TABLE `report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `student_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employer_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `job_id` bigint NOT NULL,
  `review_type` enum('EMPLOYER_TO_STUDENT','STUDENT_TO_EMPLOYER') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKd7xi2yq2g4dsw7ud83x1pugqk` (`student_id`,`job_id`,`review_type`),
  KEY `fk_review_target` (`employer_id`),
  CONSTRAINT `fk_review_reviewer` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_review_target` FOREIGN KEY (`employer_id`) REFERENCES `employer` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'ADMIN'),(3,'EMPLOYER'),(2,'STUDENT');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saved_job`
--

DROP TABLE IF EXISTS `saved_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `saved_job` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `student_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_id` bigint DEFAULT NULL,
  `saved_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_saved_student` (`student_id`),
  KEY `fk_saved_job` (`job_id`),
  CONSTRAINT `fk_saved_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_saved_student` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saved_job`
--

LOCK TABLES `saved_job` WRITE;
/*!40000 ALTER TABLE `saved_job` DISABLE KEYS */;
INSERT INTO `saved_job` VALUES (1,NULL,3,'2026-04-30 08:34:44'),(2,NULL,3,'2026-04-30 08:34:53'),(3,NULL,7,'2026-04-30 08:34:54'),(4,NULL,5,'2026-05-01 00:02:41'),(5,NULL,3,'2026-05-01 00:02:48'),(6,NULL,7,'2026-05-01 00:02:52'),(7,NULL,3,'2026-05-01 00:02:52'),(8,NULL,3,'2026-05-01 00:07:57'),(9,NULL,7,'2026-05-01 00:07:58'),(10,NULL,3,'2026-05-01 00:08:02'),(11,NULL,7,'2026-05-01 00:08:03'),(12,NULL,3,'2026-05-01 00:08:08'),(13,NULL,7,'2026-05-01 00:08:09'),(14,NULL,1,'2026-05-01 00:08:13'),(15,NULL,2,'2026-05-01 00:08:15'),(16,NULL,2,'2026-05-01 00:08:15'),(17,NULL,3,'2026-05-01 00:08:24'),(18,NULL,7,'2026-05-01 00:13:42'),(19,NULL,7,'2026-05-01 00:13:44'),(20,NULL,7,'2026-05-01 00:13:45'),(21,NULL,7,'2026-05-01 00:13:47'),(22,NULL,3,'2026-05-01 00:13:51'),(23,NULL,3,'2026-05-01 00:13:59'),(24,NULL,7,'2026-05-01 00:14:00'),(25,NULL,7,'2026-05-01 00:15:05'),(26,NULL,3,'2026-05-01 00:15:10'),(27,NULL,7,'2026-05-01 00:15:11'),(28,NULL,3,'2026-05-01 00:15:42'),(29,NULL,3,'2026-05-01 00:16:19'),(30,NULL,7,'2026-05-01 00:16:25'),(31,NULL,3,'2026-05-01 00:16:30'),(32,NULL,3,'2026-05-01 00:17:00'),(33,NULL,3,'2026-05-01 00:21:06'),(41,'58084ac6-666e-4bd8-801a-2c03cc728e36',12,'2026-05-05 07:16:10');
/*!40000 ALTER TABLE `saved_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_busy_slots`
--

DROP TABLE IF EXISTS `schedule_busy_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule_busy_slots` (
  `schedule_id` bigint NOT NULL,
  `time_slot_id` bigint NOT NULL,
  PRIMARY KEY (`schedule_id`,`time_slot_id`),
  KEY `time_slot_id` (`time_slot_id`),
  CONSTRAINT `schedule_busy_slots_ibfk_1` FOREIGN KEY (`schedule_id`) REFERENCES `student_schedules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `schedule_busy_slots_ibfk_2` FOREIGN KEY (`time_slot_id`) REFERENCES `time_slots` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_busy_slots`
--

LOCK TABLES `schedule_busy_slots` WRITE;
/*!40000 ALTER TABLE `schedule_busy_slots` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule_busy_slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_config`
--

DROP TABLE IF EXISTS `schedule_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule_config` (
  `id` bigint NOT NULL,
  `full_enabled` bit(1) DEFAULT NULL,
  `full_frequency` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `incremental_enabled` bit(1) DEFAULT NULL,
  `incremental_every` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_config`
--

LOCK TABLES `schedule_config` WRITE;
/*!40000 ALTER TABLE `schedule_config` DISABLE KEYS */;
INSERT INTO `schedule_config` VALUES (1,_binary '','daily','02:00',_binary '','6');
/*!40000 ALTER TABLE `schedule_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student` (
  `id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `university` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `major` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `rating` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_student_user` FOREIGN KEY (`id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES ('58084ac6-666e-4bd8-801a-2c03cc728e36','đại học fpt','aaaaa','aaaa',NULL,NULL,NULL),('6b98418d-4b9f-4754-8e4d-bcd574f6848c','FPT University','Software Engineering',NULL,NULL,NULL,NULL),('dfce784b-5bf8-4667-889b-15b5d31c4244','aaaa','aaaa','aaaa',NULL,NULL,NULL),('f4719adc-0dc3-4756-9d17-ae157be2b270',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_schedules`
--

DROP TABLE IF EXISTS `student_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_schedules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `day_of_week` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`day_of_week`),
  CONSTRAINT `student_schedules_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_schedules`
--

LOCK TABLES `student_schedules` WRITE;
/*!40000 ALTER TABLE `student_schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `time_slots`
--

DROP TABLE IF EXISTS `time_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `time_slots` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `start_time` (`start_time`,`end_time`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `time_slots`
--

LOCK TABLES `time_slots` WRITE;
/*!40000 ALTER TABLE `time_slots` DISABLE KEYS */;
INSERT INTO `time_slots` VALUES (1,'00:00:00','01:00:00'),(2,'01:00:00','02:00:00'),(3,'02:00:00','03:00:00'),(4,'03:00:00','04:00:00'),(5,'04:00:00','05:00:00'),(6,'05:00:00','06:00:00'),(7,'06:00:00','07:00:00'),(8,'07:00:00','08:00:00'),(9,'08:00:00','09:00:00'),(10,'09:00:00','10:00:00'),(11,'10:00:00','11:00:00'),(12,'11:00:00','12:00:00'),(13,'12:00:00','13:00:00'),(14,'13:00:00','14:00:00'),(15,'14:00:00','15:00:00'),(16,'15:00:00','16:00:00'),(17,'16:00:00','17:00:00'),(18,'17:00:00','18:00:00'),(19,'18:00:00','19:00:00'),(20,'19:00:00','20:00:00'),(21,'20:00:00','21:00:00'),(22,'21:00:00','22:00:00'),(23,'22:00:00','23:00:00'),(24,'23:00:00','00:00:00');
/*!40000 ALTER TABLE `time_slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `phone_number` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_blocked` tinyint(1) DEFAULT NULL,
  `is_actived` tinyint(1) DEFAULT NULL,
  `role_id` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_users_role_id` (`role_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('35473d19-68ad-47e8-9c63-aecd42f5c4d4','admin','admin@unipart.vn','$2a$10$pd9hhjnzZoEEPM5OBI52Suq7iL34Xwd3lhYCYBEfIEbGGPIrQ9VW2',NULL,'Administrator',NULL,NULL,NULL,0,1,1,NULL,NULL),('58084ac6-666e-4bd8-801a-2c03cc728e36','Nguyễn Minh Hiếudz','nguyenhieutd2k4@gmail.com','$2a$10$3gaR3pgV4kB4cLds82Rz/uHYZN0S0RjUVMbrz/UmShH3XvPnkexlC','https://res.cloudinary.com/duxnckhkq/image/upload/v1777536955/aedssnp4rttxjkiijmtb.webp','Nguyễn Minh Hiếu','2004-04-17','0973401516','Male',0,1,2,'2026-04-30 01:03:21',NULL),('6b98418d-4b9f-4754-8e4d-bcd574f6848c','student','student@gmail.com','$2a$10$9Q2nDURaPg5KGm0SJ9WhiOzatgqu2c6VpPxltYY2NZvM2p7jaTPUa',NULL,'student',NULL,NULL,NULL,0,1,2,NULL,NULL),('89d76d9c-ce71-4de1-ab86-fb3f78ac964c','employer','employer@gmail.com','$2a$10$bP/ZTa.bMTaGoeJtijEA4OnUi.F0ylFAKyFntyofh7s9YOgONAQDq','https://res.cloudinary.com/duxnckhkq/image/upload/v1777908176/ru7q3tocrr20xmxaf0w9.webp','employer','2004-05-01','0973401517','MALE',0,1,3,NULL,'2026-05-04 08:24:04'),('dfce784b-5bf8-4667-889b-15b5d31c4244','hieu01','nguyenminhhieucoder01@gmail.com','$2a$10$qfKn.DZe4C87bV6z/cZVHObDv44iWPJ3Eq5iRqLALPje/HOS8PD.2',NULL,'Nguyễn Minh Hiếu','2004-12-20','0973401516','Male',0,1,2,'2026-05-05 17:07:45',NULL),('EMP001','employer1',NULL,'hashed_pass',NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2026-04-30 08:01:41','2026-04-30 08:01:41'),('f4719adc-0dc3-4756-9d17-ae157be2b270','hieu','minhhieu@gmail.com','$2a$10$isi98dc/.KfL4i/SXrKyJuoQ.OdXCQIWpvuVrA8OF9cm4xBQnXZG.',NULL,'Nguyễn Minh Hiếu',NULL,NULL,NULL,0,0,2,'2026-05-05 01:28:47',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-07  8:18:46
