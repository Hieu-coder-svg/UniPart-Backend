-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: UniPartDB
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `UniPartDB`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `UniPartDB` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `UniPartDB`;

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applications` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `applied_at` datetime(6) DEFAULT NULL,
  `completed_at` datetime(6) DEFAULT NULL,
  `job_id` bigint NOT NULL,
  `status` varchar(20) NOT NULL,
  `student_id` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK65weib1lru9dkrbto5pv389vi` (`job_id`),
  KEY `FK85nvnisa8dt52msss2v68t0lh` (`student_id`),
  CONSTRAINT `FK65weib1lru9dkrbto5pv389vi` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`),
  CONSTRAINT `FK85nvnisa8dt52msss2v68t0lh` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applications`
--

LOCK TABLES `applications` WRITE;
/*!40000 ALTER TABLE `applications` DISABLE KEYS */;
INSERT INTO `applications` VALUES (1,'2026-04-22 16:11:03.000000','2026-04-22 09:55:17.825405',1,'COMPLETED','stu-001'),(2,'2026-04-22 16:11:03.000000','2026-05-12 03:05:48.617633',1,'COMPLETED','stu-002'),(3,'2026-04-22 16:11:03.000000','2026-04-24 09:03:38.016065',1,'REJECTED','stu-003'),(6,'2026-05-11 09:45:36.228185','2026-05-12 03:05:46.981489',5,'COMPLETED','stu-001'),(7,'2026-05-11 09:52:14.306146','2026-05-11 10:11:03.768950',3,'COMPLETED','stu-001');
/*!40000 ALTER TABLE `applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_history`
--

DROP TABLE IF EXISTS `backup_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `date` datetime(6) NOT NULL,
  `duration` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_history`
--

LOCK TABLES `backup_history` WRITE;
/*!40000 ALTER TABLE `backup_history` DISABLE KEYS */;
INSERT INTO `backup_history` VALUES (1,'2026-05-11 09:50:13.355724','0 giây','backup_full_2026-05-11_16-50-13.zip','completed','full'),(2,'2026-05-12 03:10:26.044219',NULL,'backup_full_2026-05-12_10-10-26.zip','running','full');
/*!40000 ALTER TABLE `backup_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK41g4n0emuvcm3qyf1f6cn43c0` (`category_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Kinh nghiệm làm việc','Chia sẻ kinh nghiệm từ các bạn sinh viên'),(2,'Kinh nghiệm làm việc234','Chia sẻ kinh nghiệm từ các bạn sinh viên234'),(3,'Kinh nghiệm làm việc234653','Chia sẻ kinh nghiệm từ các bạn sinh viên2342323');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_messages`
--

DROP TABLE IF EXISTS `chat_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_messages` (
  `id` varchar(255) NOT NULL,
  `content` text,
  `created_at` datetime(6) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `user_id` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6f0y4l43ihmgfswkgy9yrtjkh` (`user_id`),
  CONSTRAINT `FK6f0y4l43ihmgfswkgy9yrtjkh` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_messages`
--

LOCK TABLES `chat_messages` WRITE;
/*!40000 ALTER TABLE `chat_messages` DISABLE KEYS */;
INSERT INTO `chat_messages` VALUES ('3f189fdc-4fc7-4e96-ab6b-828fc94420cb','Cách thanh toán?','2026-05-11 08:14:51.937332','USER','emp-001'),('3f3fd766-883c-4b95-94fc-50b030237565','Việc làm F&B','2026-05-11 08:25:43.631714','USER','781dfc99-7587-412d-9652-521e3cb49bb8'),('49b2798b-ad08-4d91-a8bf-fab201c36f1a','alo','2026-05-11 08:26:05.774177','USER','781dfc99-7587-412d-9652-521e3cb49bb8'),('4df84f51-35d9-4c97-a7a7-9baa1ffa2b6e','Tìm việc lương cao','2026-05-11 08:19:25.383977','USER','781dfc99-7587-412d-9652-521e3cb49bb8'),('62f50fb2-4ee5-497f-ae93-f0962b29d83b','Ưu đãi miễn phí?','2026-05-11 09:39:01.291874','USER','emp-001'),('6df2e2c4-b563-4999-9165-c57090340a5e','alo','2026-05-11 08:26:26.726233','USER','781dfc99-7587-412d-9652-521e3cb49bb8'),('851641c3-3aad-4930-a848-add53fa18f34','alo','2026-05-11 08:26:00.274311','USER','781dfc99-7587-412d-9652-521e3cb49bb8'),('897a5459-81fb-48c9-9395-17936be2f17d','hello','2026-05-11 08:19:39.343582','USER','781dfc99-7587-412d-9652-521e3cb49bb8'),('abab6949-f71c-425c-ac8d-e3a3da0d8c15','Bảng giá các gói?','2026-05-11 08:14:46.020756','USER','emp-001');
/*!40000 ALTER TABLE `chat_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `post_id` bigint NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `parent_comment_id` bigint DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKh4c7lvsc298whoyd4w9ta25cr` (`post_id`),
  KEY `FK7h839m3lkvhbyv3bcdv7sm4fj` (`parent_comment_id`),
  KEY `FK8omq0tc18jd43bu5tjh6jvraq` (`user_id`),
  CONSTRAINT `FK14s7rnpyrouf7jani6vq4e73o` FOREIGN KEY (`user_id`) REFERENCES `student` (`id`),
  CONSTRAINT `FK7h839m3lkvhbyv3bcdv7sm4fj` FOREIGN KEY (`parent_comment_id`) REFERENCES `comments` (`id`),
  CONSTRAINT `FK8omq0tc18jd43bu5tjh6jvraq` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `FKh4c7lvsc298whoyd4w9ta25cr` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (1,'Cảm ơn bạn đã chia sẻ, rất hữu ích!','2026-04-29 03:04:42.163335',4,'stu-002',NULL,NULL),(2,'Cảm ơn bạn đã chia sẻ, rất hữu ích dsdssd!','2026-04-29 03:06:55.570252',4,'stu-001',NULL,NULL),(3,'hhsaasas','2026-05-11 14:55:52.227127',9,'stu-001',NULL,NULL),(4,'dcsscdscd','2026-05-11 15:02:00.613518',10,'stu-001',NULL,NULL),(5,'cxxxxzzx','2026-05-11 15:06:08.285573',10,'stu-001',NULL,NULL),(6,'vdfdfdvfvdf','2026-05-11 15:12:10.933581',13,'stu-001',NULL,NULL),(7,'vdvddvfddfv','2026-05-11 15:42:11.158882',13,'stu-001',6,NULL),(8,'xzxczxzc','2026-05-11 15:42:18.197293',13,'stu-001',6,NULL),(9,'vdfvfdfd','2026-05-11 15:43:15.226167',39,'stu-001',NULL,NULL),(23,'dsdssdds','2026-05-11 15:45:33.104317',39,'stu-002',9,NULL),(24,'sdcnjcdsjscdncdsjnjdc','2026-05-11 15:46:21.018692',39,'stu-002',9,NULL),(25,'dscdsdscdsc','2026-05-11 15:47:18.472133',39,'stu-002',9,NULL),(26,'cdsscdscdd','2026-05-11 15:48:08.980369',39,'stu-002',NULL,NULL),(27,'sdcdsscddsc','2026-05-11 15:50:27.508225',39,'stu-002',9,NULL),(28,'dsdssdcscd','2026-05-11 15:57:09.278874',39,'stu-001',9,NULL),(29,'v dfvdvfdfdf','2026-05-11 15:59:36.394544',39,'stu-001',9,NULL),(30,'dsdcsdcsdsc','2026-05-11 16:03:59.054895',39,'stu-001',26,NULL),(31,'vsvsddsccs','2026-05-11 16:15:14.097889',10,'stu-001',4,NULL),(32,'','2026-05-11 16:27:48.409899',39,'stu-001',26,'https://res.cloudinary.com/duxnckhkq/image/upload/v1778516867/hdb7dyrkk2wzgotb4gmk.png'),(33,'cdscdscsdscd','2026-05-11 16:45:21.631437',40,'stu-001',NULL,NULL),(34,'scdscdcsdcsd','2026-05-11 16:45:23.572029',40,'stu-001',NULL,NULL),(35,'','2026-05-12 03:01:34.045370',41,'stu-001',NULL,'https://res.cloudinary.com/duxnckhkq/image/upload/v1778554890/dya7ljhayfdezu9pnpxp.png');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employer`
--

DROP TABLE IF EXISTS `employer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employer` (
  `id` varchar(50) NOT NULL,
  `company_address` varchar(255) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `description` text,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `rating` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK8bbwi5dn2pgdubxficfaggug` FOREIGN KEY (`id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employer`
--

LOCK TABLES `employer` WRITE;
/*!40000 ALTER TABLE `employer` DISABLE KEYS */;
INSERT INTO `employer` VALUES ('6d1d53f5-52e2-4b37-b2aa-4fcc3988fb00',NULL,'Highlands Coffee',NULL,10.845,106.812,NULL),('emp-001','Ha Noi','Cafe ABC','Quan cafe part-time',21.0285,105.8542,5);
/*!40000 ALTER TABLE `employer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employer_package_purchase`
--

DROP TABLE IF EXISTS `employer_package_purchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employer_package_purchase` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `employer_id` varchar(50) NOT NULL,
  `end_date` datetime(6) DEFAULT NULL,
  `package_id` bigint NOT NULL,
  `price_paid` decimal(12,2) NOT NULL,
  `purchased_at` datetime(6) NOT NULL,
  `start_date` datetime(6) DEFAULT NULL,
  `tins_purchased` int DEFAULT NULL,
  `payment_status` tinyint DEFAULT NULL,
  `transaction_ref` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKcbhovy0ukuijym2a1rnhl88y1` (`employer_id`),
  KEY `FKmu7yt3hourkthkbrxxke3tatm` (`package_id`),
  CONSTRAINT `FKcbhovy0ukuijym2a1rnhl88y1` FOREIGN KEY (`employer_id`) REFERENCES `employer` (`id`),
  CONSTRAINT `FKmu7yt3hourkthkbrxxke3tatm` FOREIGN KEY (`package_id`) REFERENCES `package` (`id`),
  CONSTRAINT `employer_package_purchase_chk_1` CHECK ((`payment_status` between 0 and 2))
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employer_package_purchase`
--

LOCK TABLES `employer_package_purchase` WRITE;
/*!40000 ALTER TABLE `employer_package_purchase` DISABLE KEYS */;
INSERT INTO `employer_package_purchase` VALUES (1,'emp-001','2026-05-23 08:43:18.766296',1,199000.00,'2026-04-23 08:41:26.054766','2026-04-23 08:43:18.766296',NULL,1,'a527ec7d89e6'),(2,'emp-001',NULL,2,50000.00,'2026-04-24 09:05:50.820456','2026-04-24 09:07:50.906943',NULL,1,'48ba32c9eb6d'),(3,'emp-001',NULL,2,50000.00,'2026-05-11 10:41:15.049404',NULL,NULL,0,'67e84e2939b6'),(4,'emp-001',NULL,3,299000.00,'2026-05-11 10:41:32.698153',NULL,NULL,0,'32975565e7e9'),(5,'emp-001',NULL,2,50000.00,'2026-05-11 10:42:32.284402',NULL,NULL,0,'c2c0e1f4925d'),(6,'emp-001',NULL,1,199000.00,'2026-05-11 10:43:54.883115',NULL,NULL,0,'95dd071d6ab0'),(7,'emp-001',NULL,1,199000.00,'2026-05-11 10:46:25.991747',NULL,NULL,0,'a2d63321f399'),(8,'emp-001','2026-06-10 10:53:03.310436',2,50000.00,'2026-05-11 10:46:53.657116','2026-05-11 10:53:03.310436',NULL,1,'6d4a88aedac7'),(9,'emp-001','2026-06-10 10:53:43.586028',3,299000.00,'2026-05-11 10:53:11.917880','2026-05-11 10:53:43.586028',NULL,1,'54511e9fafc4'),(10,'emp-001','2026-06-10 10:56:17.561540',3,299000.00,'2026-05-11 10:55:42.707635','2026-05-11 10:56:17.561540',NULL,1,'d70005738fdb'),(11,'emp-001','2026-06-10 10:57:00.086462',3,299000.00,'2026-05-11 10:56:37.596856','2026-05-11 10:57:00.086462',NULL,1,'882ac3078805'),(12,'emp-001',NULL,3,299000.00,'2026-05-11 10:58:59.010735',NULL,NULL,0,'377aa7a757c3');
/*!40000 ALTER TABLE `employer_package_purchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invalidated_token`
--

DROP TABLE IF EXISTS `invalidated_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invalidated_token` (
  `id` varchar(255) NOT NULL,
  `expiry_date` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invalidated_token`
--

LOCK TABLES `invalidated_token` WRITE;
/*!40000 ALTER TABLE `invalidated_token` DISABLE KEYS */;
INSERT INTO `invalidated_token` VALUES ('238e22d5-4c9b-4c6a-b564-75bcc15c46ef','2026-10-08 08:25:29.000000'),('3ba5caa7-2ec9-4302-acc4-b730c47937e1','2026-09-28 02:32:01.000000'),('534b277f-e53a-4258-af14-5afa1e5ee222','2026-09-28 02:41:36.000000'),('57b80c26-5281-4280-ab31-f412b24d124a','2026-10-08 11:00:44.000000'),('5c7df84e-1bfa-455b-9034-3529d2d41e07','2026-10-08 08:15:54.000000'),('6b7f01ae-4d3d-4763-b92f-f023ca31c9ac','2026-10-08 09:54:39.000000'),('6d567218-040d-4f63-80ff-75b14dc4b249','2026-10-08 15:43:46.000000'),('6fc65e0b-0d40-4539-a844-4d52128da243','2026-10-08 10:11:25.000000'),('7cc2aaa4-844d-42a6-8132-4fcd6979a97d','2026-09-28 03:07:19.000000'),('86facd2b-1910-4bd7-bd6b-a61d2dcf79d2','2026-09-28 02:40:03.000000'),('974e28de-d5ba-47e7-a054-5f9275674d19','2026-10-09 03:03:46.000000'),('98662c60-4720-489a-bde4-9ee0c3a1d560','2026-10-08 09:50:07.000000'),('9fdaf144-773b-4ef0-a456-29d5454e79a6','2026-10-08 09:38:44.000000'),('a3097117-2428-4ce6-b015-0485de8e5afb','2026-10-08 08:28:43.000000'),('b0b4f0de-d709-47b0-91ec-5db28c1a0e79','2026-10-08 14:57:04.000000'),('bc8eab0f-0c2a-4443-947c-872be50e50df','2026-10-08 08:29:44.000000'),('c08a2a3b-bc5a-4d3b-baf5-90a7ba462761','2026-09-28 02:48:25.000000'),('c2a7d460-8908-45cd-be31-23f823be9a35','2026-10-08 09:44:53.000000'),('d365db9b-3911-4526-baab-260a906d4993','2026-09-28 02:30:13.000000'),('d3a40d6a-16cd-4f08-b425-5b4b5c463622','2026-10-08 10:37:37.000000'),('e3c92051-b416-4a82-8722-c65e8e2222ad','2026-10-08 10:46:10.000000'),('ea691906-f812-4e36-ba5a-d4828e1d7254','2026-10-08 08:14:04.000000'),('f5e5352e-0734-4195-a85f-5a8b47cf003b','2026-09-28 02:52:41.000000'),('ff8d0388-f5fe-418a-9bf6-26360b70dc82','2026-10-09 03:05:08.000000');
/*!40000 ALTER TABLE `invalidated_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_time_slots`
--

DROP TABLE IF EXISTS `job_time_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_time_slots` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `end_time` time NOT NULL,
  `job_id` bigint NOT NULL,
  `start_time` time NOT NULL,
  `work_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKg1580r9uwcdsh2ydsm151wgaa` (`job_id`),
  CONSTRAINT `FKg1580r9uwcdsh2ydsm151wgaa` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_time_slots`
--

LOCK TABLES `job_time_slots` WRITE;
/*!40000 ALTER TABLE `job_time_slots` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_time_slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `description` text,
  `employer_id` varchar(50) NOT NULL,
  `expired_at` datetime(6) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `is_hide` bit(1) DEFAULT NULL,
  `location_latitude` decimal(10,8) DEFAULT NULL,
  `location_longitude` decimal(11,8) DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `title` varchar(100) NOT NULL,
  `urgent` bit(1) DEFAULT NULL,
  `vacancies` int NOT NULL,
  `working_shift` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1rx2n3e5npgq47kqy0dm4r8tr` (`employer_id`),
  CONSTRAINT `FK1rx2n3e5npgq47kqy0dm4r8tr` FOREIGN KEY (`employer_id`) REFERENCES `employer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (1,'Ha Noi','2026-04-22 16:10:54.000000','Part-time ca tối','emp-001',NULL,NULL,_binary '\0',NULL,NULL,20000.00,'Phục vụ quán cafe',_binary '',2,'18h-22h'),(2,NULL,'2026-04-24 02:02:43.322714','Cần 2 bạn phục vụ gấp quanh khu vực CNC','6d1d53f5-52e2-4b37-b2aa-4fcc3988fb00','2026-05-24 02:02:43.322714',NULL,_binary '\0',10.84310000,106.81050000,25000.00,'Phục vụ Highlands Coffee - Gấp',_binary '',2,NULL),(3,NULL,'2026-04-24 02:02:43.347654','Pha chế part-time','6d1d53f5-52e2-4b37-b2aa-4fcc3988fb00','2026-05-24 02:02:43.347654',NULL,_binary '\0',10.79630000,106.73230000,28000.00,'Pha chế Phúc Long Q2',_binary '\0',5,NULL),(4,NULL,'2026-04-24 02:02:43.356448','Trông xe part-time Gò Vấp','6d1d53f5-52e2-4b37-b2aa-4fcc3988fb00','2026-05-24 02:02:43.356448',NULL,_binary '\0',10.83860000,106.66660000,22000.00,'Bảo vệ quán net Gò Vấp',_binary '\0',1,NULL),(5,'','2026-05-11 08:17:29.464189','cscsdscdscd','emp-001','2026-05-18 01:16:57.000000',NULL,_binary '',NULL,NULL,10.00,'dscdsds',_binary '\0',1,'Ca Chiều');
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` text,
  `created_at` datetime(6) DEFAULT NULL,
  `is_read` bit(1) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `user_id` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKnk4ftb5am9ubmkv1661h15ds9` (`user_id`),
  CONSTRAINT `FKnk4ftb5am9ubmkv1661h15ds9` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES (1,'Sinh viên Nguyen Van A muốn làm công việc Phục vụ Highlands Coffee - Gấp','2026-05-11 08:29:58.850699',_binary '\0','Ứng tuyển công việc','6d1d53f5-52e2-4b37-b2aa-4fcc3988fb00'),(2,'Sinh viên Nguyen Van A muốn làm công việc dscdsds','2026-05-11 09:45:36.262867',_binary '\0','Ứng tuyển công việc','emp-001'),(3,'Sinh viên Nguyen Van A đã hủy công việc Phục vụ Highlands Coffee - Gấp','2026-05-11 09:47:20.126034',_binary '\0','Hủy ứng tuyển công việc','6d1d53f5-52e2-4b37-b2aa-4fcc3988fb00'),(4,'Sinh viên Nguyen Van A muốn làm công việc Pha chế Phúc Long Q2','2026-05-11 09:52:14.318968',_binary '\0','Ứng tuyển công việc','6d1d53f5-52e2-4b37-b2aa-4fcc3988fb00');
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otp`
--

DROP TABLE IF EXISTS `otp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `otp` (
  `id` varchar(255) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `email` varchar(255) NOT NULL,
  `expiration_time` datetime(6) NOT NULL,
  `is_used` bit(1) NOT NULL,
  `otp_code` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otp`
--

LOCK TABLES `otp` WRITE;
/*!40000 ALTER TABLE `otp` DISABLE KEYS */;
/*!40000 ALTER TABLE `otp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package`
--

DROP TABLE IF EXISTS `package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `package` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `description` text,
  `duration_days` int DEFAULT NULL,
  `max_normal_tins_per_day` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `normal_tins_limit` int DEFAULT NULL,
  `package_type` varchar(20) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `tin_quantity` int DEFAULT NULL,
  `tin_type` varchar(20) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `urgent_tins_limit` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package`
--

LOCK TABLES `package` WRITE;
/*!40000 ALTER TABLE `package` DISABLE KEYS */;
INSERT INTO `package` VALUES (1,'2026-04-23 02:52:53.610934','Dành cho nhà tuyển dụng nhỏ',30,2,'Gói tháng cơ bản',10,'MONTHLY',199000.00,NULL,NULL,'2026-04-23 02:52:53.610934',2),(2,'2026-04-23 03:10:50.654954','Đăng 1 tin',30,2,'Gói đăng tin lẻ',60,'ONE_TIME',50000.00,1,'NORMAL','2026-05-11 10:24:23.038422',5),(3,'2026-04-23 03:29:11.543855','Pro hơn',30,5,'Gói tháng PRO1',20,'MONTHLY',299000.00,1,'NORMAL','2026-05-11 10:24:04.737731',5);
/*!40000 ALTER TABLE `package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_likes`
--

DROP TABLE IF EXISTS `post_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_likes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `post_id` bigint NOT NULL,
  `user_id` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK5l2rj28vw5oj6f7ox746grokg` (`post_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_likes`
--

LOCK TABLES `post_likes` WRITE;
/*!40000 ALTER TABLE `post_likes` DISABLE KEYS */;
INSERT INTO `post_likes` VALUES (2,'2026-05-11 14:55:41.801913',8,'stu-001'),(7,'2026-05-11 14:56:08.355067',9,'stu-001'),(13,'2026-05-11 15:17:40.035689',24,'781dfc99-7587-412d-9652-521e3cb49bb8'),(18,'2026-05-11 15:50:17.503075',39,'stu-002'),(20,'2026-05-11 16:07:09.089933',39,'stu-001'),(21,'2026-05-11 16:45:17.936222',40,'stu-001'),(22,'2026-05-11 16:55:08.497561',41,'stu-001');
/*!40000 ALTER TABLE `post_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `related_job_id` bigint DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `user_id` varchar(50) NOT NULL,
  `category_id` bigint DEFAULT NULL,
  `comments_count` int DEFAULT NULL,
  `likes_count` int DEFAULT NULL,
  `shares_count` int DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4wcp2j0225r399tqu8ce77238` (`related_job_id`),
  KEY `FKijnwr3brs8vaosl80jg9rp7uc` (`category_id`),
  KEY `FK5lidm6cqbc7u4xhqpxm898qme` (`user_id`),
  CONSTRAINT `FK4wcp2j0225r399tqu8ce77238` FOREIGN KEY (`related_job_id`) REFERENCES `jobs` (`id`),
  CONSTRAINT `FK5lidm6cqbc7u4xhqpxm898qme` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `FKc9ctm4oia72oocotcapwxsb1u` FOREIGN KEY (`user_id`) REFERENCES `student` (`id`),
  CONSTRAINT `FKijnwr3brs8vaosl80jg9rp7uc` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (4,'Kinh nghiệm làm thêm tại quán cafe...','2026-04-29 02:59:54.624947',NULL,NULL,'stu-001',1,2,0,0,'2026-04-29 03:06:55.572879',NULL),(5,'Kinh nghiệm làm thêm tại quán cafe...dfvffdkfdvfdvfkdffdfdvnfdkdfn','2026-04-29 09:07:02.864859',NULL,NULL,'stu-001',2,0,0,0,'2026-04-29 09:07:02.864859',NULL),(6,'nbnbn','2026-05-11 14:41:45.067349',NULL,NULL,'stu-001',1,0,0,0,'2026-05-11 14:41:45.067349',NULL),(7,'bbjbjbjb','2026-05-11 14:42:30.565510',NULL,NULL,'stu-001',1,0,0,3,'2026-05-11 14:56:21.379092',NULL),(8,'dsdscdscds','2026-05-11 14:44:02.460350',NULL,NULL,'stu-001',1,0,1,9,'2026-05-11 14:56:20.052437',NULL),(9,'scd','2026-05-11 14:44:45.492949',NULL,NULL,'stu-001',1,1,1,18,'2026-05-11 14:56:17.051976',NULL),(10,'sdscdscdcdsdsc2232','2026-05-11 14:57:12.378679',NULL,NULL,'stu-001',1,3,0,14,'2026-05-11 16:15:23.762628',NULL),(11,'scdscsdscddscds','2026-05-11 15:06:23.799762',NULL,NULL,'stu-001',2,0,0,0,'2026-05-11 15:06:23.799762',NULL),(12,'sdcdsscdscd','2026-05-11 15:06:37.891453',NULL,NULL,'stu-001',3,0,0,0,'2026-05-11 15:06:37.891453',NULL),(13,'vsvddvdvffvdfdv','2026-05-11 15:07:20.209188',NULL,NULL,'stu-001',1,3,0,8,'2026-05-11 15:42:18.197293',NULL),(14,'scddssdcsddscds','2026-05-11 15:12:18.035952',NULL,NULL,'stu-001',1,0,0,0,'2026-05-11 15:12:18.035952',NULL),(15,'scddssdcsddscds','2026-05-11 15:12:19.735082',NULL,NULL,'stu-001',1,0,0,0,'2026-05-11 15:12:19.735082',NULL),(16,'scddssdcsddscds','2026-05-11 15:12:20.264011',NULL,NULL,'stu-001',1,0,0,0,'2026-05-11 15:12:20.264011',NULL),(17,'scddssdcsddscds','2026-05-11 15:12:20.487781',NULL,NULL,'stu-001',1,0,0,0,'2026-05-11 15:12:20.487781',NULL),(18,'scddssdcsddscds','2026-05-11 15:12:20.676434',NULL,NULL,'stu-001',1,0,0,0,'2026-05-11 15:12:20.676434',NULL),(19,'scddssdcsddscds','2026-05-11 15:12:20.971158',NULL,NULL,'stu-001',1,0,0,0,'2026-05-11 15:12:20.971158',NULL),(20,'scddssdcsddscds','2026-05-11 15:12:21.141279',NULL,NULL,'stu-001',1,0,0,0,'2026-05-11 15:12:21.141279',NULL),(21,'scddssdcsddscds','2026-05-11 15:12:21.322337',NULL,NULL,'stu-001',1,0,0,0,'2026-05-11 15:12:21.322337',NULL),(22,'scddssdcsddscds','2026-05-11 15:12:22.135812',NULL,NULL,'stu-001',1,0,0,0,'2026-05-11 15:12:22.135812',NULL),(23,'scddssdcsddscds','2026-05-11 15:12:22.330497',NULL,NULL,'stu-001',1,0,0,0,'2026-05-11 15:12:22.330497',NULL),(24,'scddssdcsddscds','2026-05-11 15:12:22.535402',NULL,NULL,'stu-001',1,0,1,0,'2026-05-11 15:17:40.035689',NULL),(38,'sdcdsscdscd','2026-05-11 15:17:46.873827',NULL,NULL,'stu-001',1,0,0,0,'2026-05-11 15:17:46.873827',NULL),(39,'bbggfbfgb','2026-05-11 15:18:04.596172',NULL,NULL,'stu-001',1,10,2,2,'2026-05-11 16:27:48.415204',NULL),(40,'cdsdscdsdcsc','2026-05-11 16:27:32.353997',NULL,NULL,'stu-001',1,2,1,0,'2026-05-11 16:45:23.575769','https://res.cloudinary.com/duxnckhkq/image/upload/v1778516847/rpspis0qgmvhxqkaiqnb.png'),(41,'sdcddssdcsd','2026-05-11 16:45:09.331386',NULL,NULL,'stu-001',1,1,1,4,'2026-05-12 03:01:34.095250','https://res.cloudinary.com/duxnckhkq/image/upload/v1778517907/ubtfzhhc5khgbcdxn3k8.png');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report`
--

DROP TABLE IF EXISTS `report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `reason` text,
  `reporter_id` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `target_id` varchar(50) DEFAULT NULL,
  `target_type` varchar(50) DEFAULT NULL,
  `admin_note` text,
  `resolved_by` varchar(50) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKqbhdxqd3ly7fkhly5nrl2j93k` (`reporter_id`),
  KEY `FKohgb4rfq2d25jqs4mdgy6ryho` (`resolved_by`),
  CONSTRAINT `FKohgb4rfq2d25jqs4mdgy6ryho` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`),
  CONSTRAINT `FKqbhdxqd3ly7fkhly5nrl2j93k` FOREIGN KEY (`reporter_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report`
--

LOCK TABLES `report` WRITE;
/*!40000 ALTER TABLE `report` DISABLE KEYS */;
INSERT INTO `report` VALUES (1,'2026-04-28 02:05:12.847647','Nhà tuyển dụng lừa đảo, không trả lương','stu-001','REVIEWING','emp-001','USER',NULL,'bf729637-15b7-4f1a-af11-a9aa0ac19bb3','2026-04-28 02:34:45.204607');
/*!40000 ALTER TABLE `report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `comment` text,
  `created_at` datetime(6) DEFAULT NULL,
  `employer_id` varchar(50) DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `student_id` varchar(50) DEFAULT NULL,
  `job_id` bigint NOT NULL,
  `review_type` enum('EMPLOYER_TO_STUDENT','STUDENT_TO_EMPLOYER') NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKd7xi2yq2g4dsw7ud83x1pugqk` (`student_id`,`job_id`,`review_type`),
  KEY `FKj1q1h1n111a8v1i0lubd1aiej` (`employer_id`),
  CONSTRAINT `FKaple62pi4jtfvyepa4150jbrf` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`),
  CONSTRAINT `FKj1q1h1n111a8v1i0lubd1aiej` FOREIGN KEY (`employer_id`) REFERENCES `employer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (1,'Công việc rất ổn, môi trường tốt','2026-04-27 02:50:08.600811','emp-001',5,'stu-001',1,'STUDENT_TO_EMPLOYER'),(2,'Sinh viên làm việc chăm chỉ','2026-04-27 03:08:26.355593','emp-001',4,'stu-001',1,'EMPLOYER_TO_STUDENT');
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKofx66keruapi6vyqpv6f2or37` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'ADMIN'),(3,'EMPLOYER'),(2,'STUDENT');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saved_job`
--

DROP TABLE IF EXISTS `saved_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `saved_job` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` bigint DEFAULT NULL,
  `saved_at` datetime(6) DEFAULT NULL,
  `student_id` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKi3k6x4nun86yvfd5k4699e9lp` (`job_id`),
  KEY `FK1bm3x9xywlmx6dxlmst8k2gk8` (`student_id`),
  CONSTRAINT `FK1bm3x9xywlmx6dxlmst8k2gk8` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`),
  CONSTRAINT `FKi3k6x4nun86yvfd5k4699e9lp` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saved_job`
--

LOCK TABLES `saved_job` WRITE;
/*!40000 ALTER TABLE `saved_job` DISABLE KEYS */;
/*!40000 ALTER TABLE `saved_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_busy_slots`
--

DROP TABLE IF EXISTS `schedule_busy_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule_busy_slots` (
  `schedule_id` bigint NOT NULL,
  `time_slot_id` bigint NOT NULL,
  PRIMARY KEY (`schedule_id`,`time_slot_id`),
  KEY `FKi3m1ojcpfx0tafbw86ppgb6x5` (`time_slot_id`),
  CONSTRAINT `FKi3m1ojcpfx0tafbw86ppgb6x5` FOREIGN KEY (`time_slot_id`) REFERENCES `time_slots` (`id`),
  CONSTRAINT `FKpu15cntp27ifjtawmdi1jgdc5` FOREIGN KEY (`schedule_id`) REFERENCES `student_schedules` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_busy_slots`
--

LOCK TABLES `schedule_busy_slots` WRITE;
/*!40000 ALTER TABLE `schedule_busy_slots` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule_busy_slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_config`
--

DROP TABLE IF EXISTS `schedule_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule_config` (
  `id` bigint NOT NULL,
  `full_enabled` bit(1) DEFAULT NULL,
  `full_frequency` varchar(255) DEFAULT NULL,
  `full_time` varchar(255) DEFAULT NULL,
  `incremental_enabled` bit(1) DEFAULT NULL,
  `incremental_every` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_config`
--

LOCK TABLES `schedule_config` WRITE;
/*!40000 ALTER TABLE `schedule_config` DISABLE KEYS */;
INSERT INTO `schedule_config` VALUES (1,_binary '','daily','02:00',_binary '','6');
/*!40000 ALTER TABLE `schedule_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student` (
  `id` varchar(50) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `major` varchar(255) DEFAULT NULL,
  `rating` double DEFAULT NULL,
  `university` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK3w7xmt19i6a0cr7kp8c80ek40` FOREIGN KEY (`id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES ('a6eed3ae-c526-44ad-80b4-e429cbe8824f',NULL,10.8411,106.8098,NULL,NULL,'FPT University'),('stu-001','Ha Noi',NULL,NULL,'CNTT',4,'Bach Khoa'),('stu-002','Ha Noi',NULL,NULL,'Kinh Te',3.5,'NEU'),('stu-003','Da Nang',NULL,NULL,'Software Engineering',4.2,'FPT');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_schedules`
--

DROP TABLE IF EXISTS `student_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_schedules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `day_of_week` varchar(20) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKnw3imtcuceru0nv8erfb8s7j5` (`user_id`),
  CONSTRAINT `FKnw3imtcuceru0nv8erfb8s7j5` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_schedules`
--

LOCK TABLES `student_schedules` WRITE;
/*!40000 ALTER TABLE `student_schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `time_slots`
--

DROP TABLE IF EXISTS `time_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `time_slots` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `end_time` time NOT NULL,
  `start_time` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `time_slots`
--

LOCK TABLES `time_slots` WRITE;
/*!40000 ALTER TABLE `time_slots` DISABLE KEYS */;
/*!40000 ALTER TABLE `time_slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(50) NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `is_actived` bit(1) DEFAULT NULL,
  `is_blocked` bit(1) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `phone_number` varchar(10) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `role_id` int NOT NULL,
  `avatar` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK6dotkott2kjsp8vw4d0m25fb7` (`email`),
  UNIQUE KEY `UKr43af9ap4edm43mmtq01oddj6` (`username`),
  KEY `FKp56c1712k691lhsyewcssf40f` (`role_id`),
  CONSTRAINT `FKp56c1712k691lhsyewcssf40f` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('6d1d53f5-52e2-4b37-b2aa-4fcc3988fb00',NULL,NULL,'employer@unipart.com','Test Employer',NULL,_binary '',_binary '\0','$2a$10$pURjMeBqjIEdP0/rCPC0TeL.UI2F89Zov09l8fd3JuOrZQOa.xhHO',NULL,NULL,'testemployer',3,''),('781dfc99-7587-412d-9652-521e3cb49bb8',NULL,NULL,'student@gmail.com',NULL,NULL,_binary '',_binary '\0','$2a$10$mKXWt0/Lmig6XjzpvDieSunrDAn.ebCBQSUmBRERQ47rsV8h2UegC',NULL,NULL,'student',2,''),('9e7d1e88-60c0-48f3-85b7-bcb832e39c41',NULL,NULL,'employer@gmail.com',NULL,NULL,_binary '',_binary '\0','$2a$10$pURjMeBqjIEdP0/rCPC0TeL.UI2F89Zov09l8fd3JuOrZQOa.xhHO',NULL,NULL,'employer',3,''),('a6eed3ae-c526-44ad-80b4-e429cbe8824f',NULL,NULL,'student@unipart.com','Test Student',NULL,_binary '',_binary '\0','$2a$10$2CAoczMRTq/e.8P1g4hytem02YXpZINQSD.NE4nRd00bJJ33GVrPC',NULL,NULL,'teststudent',2,''),('bf729637-15b7-4f1a-af11-a9aa0ac19bb3',NULL,NULL,'admin@gmail.com',NULL,NULL,_binary '',_binary '\0','$2a$10$pM74tdeOXm.KSHQGUyS2ceZwLgZVlZOZdrGbXg05tEXe.l6YfcL9q',NULL,NULL,'admin',1,''),('emp-001','2026-04-22 16:08:24.000000',NULL,'emp1@gmail.com','Employer One',NULL,_binary '',_binary '\0','$2a$10$pURjMeBqjIEdP0/rCPC0TeL.UI2F89Zov09l8fd3JuOrZQOa.xhHO',NULL,NULL,'employer1',3,''),('stu-001','2026-04-22 16:08:24.000000',NULL,'stu1@gmail.com','Nguyen Van A','',_binary '',_binary '\0','$2a$10$mKXWt0/Lmig6XjzpvDieSunrDAn.ebCBQSUmBRERQ47rsV8h2UegC','',NULL,'student1',2,'https://res.cloudinary.com/duxnckhkq/image/upload/v1777603768/getbmv2gwusz4wsyg4yo.png'),('stu-002','2026-04-22 16:08:24.000000',NULL,'stu2@gmail.com','Tran Thi B',NULL,_binary '',_binary '\0','$2a$10$mKXWt0/Lmig6XjzpvDieSunrDAn.ebCBQSUmBRERQ47rsV8h2UegC',NULL,NULL,'student2',2,''),('stu-003','2026-04-22 16:08:24.000000',NULL,'stu3@gmail.com','Le Van C',NULL,_binary '',_binary '\0','123456',NULL,NULL,'student3',2,'');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-12 10:10:26
